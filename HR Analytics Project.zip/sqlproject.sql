use HRproject;
##KPI1 
## Average attrition rate for all departments
SELECT Department, AVG(Attrition = 'Yes')*100 AS Attrition_Rate
FROM projectdataset
GROUP BY Department;

##KPI2
##Average hourly rate of male research scientist
select avg(hourlyrate) from projectdataset
where jobrole = 'Research Scientist' 
and gender = 'male' ;

##KPI3
##Attrition rate vs monthly income status
SELECT department, AVG(monthlyincome) as avg_monthly_income, 
       (SUM(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) / COUNT(*)) * 100 as attrition_rate
FROM projectdataset
GROUP BY department;

##KPI4
##Average working years for each department
SELECT department, AVG(totalworkingyears) as avg_working_years
FROM projectdataset
GROUP BY department;

##KPI5
##Job role vs worklife balance
SELECT distinct department, jobrole, AVG(worklifebalance) as avg_work_life_balance
FROM (SELECT DISTINCT department, jobrole, worklifebalance
      FROM projectdataset) uniqueemployees
GROUP BY department, Jobrole;

##KPI6
##Attrition rate vs year since last promotion relation
SELECT department,
       AVG(CASE WHEN attrition = 'Yes' THEN yearssincelastpromotion ELSE NULL END) as avg_years_since_last_promotion_attrition,
       AVG(CASE WHEN attrition = 'No' THEN yearssincelastpromotion ELSE NULL END) as avg_years_since_last_promotion_no_attrition
FROM projectdataset
GROUP BY department;












SELECT department,
       AVG(CASE WHEN attrition = 'Yes' THEN yearssincelastpromotion ELSE NULL END) as avg_years_since_last_promotion_attrition,
       AVG(CASE WHEN attrition = 'No' THEN yearssincelastpromotion ELSE NULL END) as avg_years_since_last_promotion_no_attrition
FROM projectdataset
GROUP BY department;
 





